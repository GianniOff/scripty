# -*- coding: utf-8 -*-
"""
Voice Panel - panneau web minimal pour connecter des BOTS Discord en vocal.

Plafond RAM (mem_limit_mb, defaut 245 Mo, jamais depasse) :
  1. max_online limite le nombre de comptes en ligne en meme temps
     (levier principal : la RAM est bornee par construction) ;
  2. un garde-fou surveille la RAM reelle (RSS) toutes les 5 s et eteint
     des comptes a 65 % / 80 % / 92 % de la limite ;
  3. discord.py est importe paresseusement et gc est force apres chaque
     extinction de compte ;
  4. hard_rlimit (option) : plafond applique par le noyau en dernier recours.

Les tokens restent dans tokens.json et ne sont jamais envoyes au navigateur.
Un compte deja en vocal n'est jamais repris ("en cours d'utilisation").
Connexion refusee dans les salons sans personne de non-mute.
"""

import asyncio
import gc
import json
import os
import pathlib
import subprocess
import sys
import time

import aiohttp
from aiohttp import web

discord = None  # import paresseux : le panneau seul tourne sans discord.py

BASE = pathlib.Path(__file__).resolve().parent
CONFIG = json.loads((BASE / "config.json").read_text(encoding="utf-8"))
GUILD_ID = int(CONFIG["guild_id"])
SELF_DEAF = bool(CONFIG.get("self_deaf", True))
PANEL_KEY = str(CONFIG.get("panel_password", "") or "")
HOST = str(CONFIG.get("host", "127.0.0.1"))
PORT = int(CONFIG.get("port", 8080))
MEM_LIMIT_MB = max(64, int(CONFIG.get("mem_limit_mb", 245)))
MAX_ONLINE = max(1, int(CONFIG.get("max_online", 2)))
IDLE_SHUTDOWN_SEC = max(30, int(CONFIG.get("idle_shutdown_sec", 120)))
HARD_RLIMIT = bool(CONFIG.get("hard_rlimit", False))
API = "https://discord.com/api/v10"
SOFT1 = int(MEM_LIMIT_MB * 0.65)
SOFT2 = int(MEM_LIMIT_MB * 0.80)
EMERG = int(MEM_LIMIT_MB * 0.92)

INDEX_HTML = (BASE / "web" / "index.html").read_text(encoding="utf-8")

ACCOUNTS = []
CHANNEL_CACHE = []
CHANNEL_ERROR = None
TASKS = []
_HTTP = None
GUARD = {"message": "", "ts": {}}


def spawn(task):
    """Cree une tache et purge les taches terminees (hygiene memoire)."""
    TASKS.append(task)
    TASKS[:] = [t for t in TASKS if not t.done()]
    return task


def _page_size():
    try:
        return os.sysconf("SC_PAGE_SIZE")
    except Exception:
        return 4096


_PAGE = _page_size()


def current_rss_mb():
    """RAM reelle du processus (Mo). Linux: /proc ; sinon psutil ; sinon ps."""
    try:
        with open("/proc/self/statm", "rb") as f:
            resident = int(f.read().split()[1])
        return resident * _PAGE / (1024.0 * 1024.0)
    except Exception:
        pass
    try:
        import psutil  # optionnel
        return psutil.Process(os.getpid()).memory_info().rss / (1024.0 * 1024.0)
    except Exception:
        pass
    try:
        out = subprocess.run(
            ["ps", "-o", "rss=", "-p", str(os.getpid())],
            capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        if out:
            return float(out.split()[-1]) / 1024.0
    except Exception:
        pass
    try:
        import resource
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return peak / 1024.0 if sys.platform == "linux" else peak / (1024.0 * 1024.0)
    except Exception:
        return 0.0


def set_guard(msg):
    GUARD["message"] = msg
    print("[RAM] " + msg)


def apply_hard_rlimit():
    """Plafond noyau optionnel (Linux). Compte la memoire virtuelle, pas la
    RAM reelle : peut couper avant l'heure, d'ou defaut desactive."""
    if not HARD_RLIMIT:
        return
    try:
        import resource
        cap = MEM_LIMIT_MB * 1024 * 1024
        resource.setrlimit(resource.RLIMIT_AS, (cap, cap))
        print("[RAM] plafond noyau RLIMIT_AS = %d Mo" % MEM_LIMIT_MB)
    except Exception as exc:
        print("[RAM] plafond noyau indisponible (%s) - le garde-fou RSS reste actif" % type(exc).__name__)


def unmuted_humans(channel):
    """Nombre d'humains non-mute (et non sourds) actuellement dans le salon."""
    n = 0
    for m in getattr(channel, "members", []):
        vs = m.voice
        if m.bot or vs is None:
            continue
        if vs.self_mute or vs.mute or vs.self_deaf or vs.deaf:
            continue
        n += 1
    return n


class Account:
    """Un bot : gateway demarre a la demande, coupe des qu'il ne sert plus."""

    def __init__(self, label, token):
        self.label = label
        self.token = token
        self.client = None
        self.error = None
        self.channel_name = None
        self.lock = asyncio.Lock()

    @property
    def ready(self):
        return self.client is not None and self.client.is_ready()

    @property
    def voice(self):
        if self.client and self.client.voice_clients:
            return self.client.voice_clients[0]
        return None

    async def _wait_ready(self, seconds=10.0):
        for _ in range(int(seconds * 10)):
            if self.client is None or self.ready or self.error:
                return
            await asyncio.sleep(0.1)

    async def ensure_started(self):
        global discord
        if self.client is not None:
            await self._wait_ready(5)
            return
        if discord is None:
            import discord as _discord
            discord = _discord
        intents = discord.Intents.none()
        intents.guilds = True
        intents.voice_states = True
        flags = discord.MemberCacheFlags.from_intents(intents)
        flags.voice = True  # cache minimal : uniquement les gens en vocal
        client = discord.Client(
            intents=intents,
            chunk_guilds_at_startup=False,
            member_cache_flags=flags,
            max_messages=None,
        )
        self.error = None
        self.client = client

        @client.event
        async def on_ready():
            print("[%s] en ligne : %s" % (self.label, client.user))

        async def runner():
            try:
                await client.start(self.token)
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                self.error = "connexion impossible (%s)" % type(exc).__name__
                print("[%s] %s" % (self.label, self.error))
            finally:
                if self.client is client:
                    self.client = None

        spawn(asyncio.create_task(runner()))
        await self._wait_ready(10)

    async def _close_locked(self):
        if self.client is not None:
            try:
                await self.client.close()
            except Exception:
                pass
        self.client = None
        self.channel_name = None
        gc.collect()

    async def safe_shutdown(self):
        async with self.lock:
            await self._close_locked()

    def schedule_idle_shutdown(self, delay=IDLE_SHUTDOWN_SEC):
        """Eteint le compte s'il reste en ligne sans vocal (RAM)."""

        async def _timer():
            await asyncio.sleep(delay)
            if self.lock.locked():
                return
            if self.ready and self.voice is None:
                await self.safe_shutdown()

        spawn(asyncio.create_task(_timer()))

    async def join(self, channel_id):
        async with self.lock:
            await self.ensure_started()
            if not self.ready:
                return False, self.error or "le compte n'arrive pas a se connecter"
            me = self.client.user
            if me is None or not me.bot:
                self.error = "token de compte utilisateur refuse - utilise un token de BOT"
                await self._close_locked()
                return False, self.error
            guild = self.client.get_guild(GUILD_ID)
            if guild is None:
                self.schedule_idle_shutdown()
                return False, "bot absent du serveur - invite-le (voir README)"
            channel = guild.get_channel(channel_id)
            if type(channel).__name__ not in ("VoiceChannel", "StageChannel"):
                self.schedule_idle_shutdown()
                return False, "salon vocal introuvable"
            if unmuted_humans(channel) == 0:
                self.schedule_idle_shutdown()
                return False, "refuse : personne de non-mute dans ce salon"
            try:
                vc = guild.voice_client
                if vc is None or not vc.is_connected():
                    await channel.connect(self_deaf=SELF_DEAF, timeout=20)
                else:
                    await vc.move_to(channel)
                    if SELF_DEAF and not getattr(vc, "self_deaf", True):
                        try:
                            await vc.edit_self_deaf(True)
                        except Exception:
                            pass
            except Exception as exc:
                self.schedule_idle_shutdown()
                return False, "connexion vocale echouee (%s)" % type(exc).__name__
            self.channel_name = channel.name
            return True, "connecte dans << %s >>" % channel.name

    async def leave(self):
        async with self.lock:
            vc = self.voice
            if vc is not None:
                try:
                    await vc.disconnect(force=True)
                except Exception:
                    pass
            await self._close_locked()
            return True, "deconnecte"


def load_accounts():
    path = BASE / "tokens.json"
    if not path.exists():
        print("tokens.json introuvable : copie le fichier fourni et colle tes tokens de bots dedans.")
        raise SystemExit(1)
    data = json.loads(path.read_text(encoding="utf-8"))
    ACCOUNTS.clear()
    for i, acc in enumerate(data.get("accounts", []), 1):
        token = (acc.get("token") or "").strip()
        if not token or token.startswith("COLLE_ICI"):
            continue
        ACCOUNTS.append(Account(acc.get("label") or ("Bot %d" % i), token))
    if not ACCOUNTS:
        print("Aucun token valide dans tokens.json.")
        raise SystemExit(1)


def authorized(request):
    if not PANEL_KEY:
        return True
    return (
        request.headers.get("X-Panel-Key") == PANEL_KEY
        or request.query.get("key") == PANEL_KEY
    )


def live_counts():
    """Comptes (non-mute, total) par salon, via un compte en ligne si dispo."""
    counts = {}
    for a in ACCOUNTS:
        if not a.ready:
            continue
        guild = a.client.get_guild(GUILD_ID)
        if guild is None:
            continue
        for ch in list(guild.voice_channels) + list(guild.stage_channels):
            counts[ch.id] = (
                unmuted_humans(ch),
                len([m for m in ch.members if m.voice is not None]),
            )
    return counts


async def http_session():
    global _HTTP
    if _HTTP is None or _HTTP.closed:
        _HTTP = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
    return _HTTP


async def _fetch_once(token):
    headers = {"Authorization": "Bot %s" % token}
    try:
        session = await http_session()
        async with session.get(
            "%s/guilds/%d/channels" % (API, GUILD_ID), headers=headers
        ) as resp:
            if resp.status == 401:
                return None, "token invalide (401)"
            if resp.status in (403, 404):
                return None, "bot pas invite sur ce serveur ou guild_id invalide"
            if resp.status != 200:
                return None, "erreur HTTP %d" % resp.status
            data = await resp.json()
    except Exception as exc:
        return None, "erreur reseau (%s)" % type(exc).__name__
    out = [
        {"id": ch["id"], "name": ch["name"], "humans": None, "total": None}
        for ch in data
        if ch.get("type") in (2, 13)
    ]
    out.sort(key=lambda c: c["name"].lower())
    return out, None


async def fetch_channels():
    last = "aucun token"
    for a in ACCOUNTS:
        data, err = await _fetch_once(a.token)
        if err is None:
            return data, None
        last = "%s : %s" % (a.label, err)
    return [], last


async def memory_watchdog():
    """Garde-fou : garde la RAM reelle sous la limite, coute que coute."""
    await asyncio.sleep(5)
    while True:
        rss = current_rss_mb()
        now = time.monotonic()
        if rss >= EMERG:
            set_guard("%.0f Mo >= seuil critique (%d Mo) : extinction de tous les comptes"
                      % (rss, EMERG))
            for a in ACCOUNTS:
                await a.safe_shutdown()
        elif rss >= SOFT2 and now - GUARD["ts"].get("s2", 0) > 15:
            GUARD["ts"]["s2"] = now
            set_guard("%.0f Mo >= seuil haut (%d Mo) : deconnexion des comptes en vocal"
                      % (rss, SOFT2))
            for a in [x for x in ACCOUNTS if x.voice is not None]:
                await a.safe_shutdown()
        elif rss >= SOFT1 and now - GUARD["ts"].get("s1", 0) > 15:
            GUARD["ts"]["s1"] = now
            dropped = [a.label for a in ACCOUNTS
                       if a.ready and a.voice is None and not a.lock.locked()]
            if dropped:
                for a in [x for x in ACCOUNTS if x.ready and x.voice is None]:
                    await a.safe_shutdown()
                set_guard("%.0f Mo > seuil bas (%d Mo) : extinction des comptes inactifs (%s)"
                          % (rss, SOFT1, ", ".join(dropped)))
        await asyncio.sleep(5)


routes = web.RouteTableDef()


@routes.get("/")
async def index(request):
    return web.Response(text=INDEX_HTML, content_type="text/html")


@routes.get("/api/state")
async def api_state(request):
    if not authorized(request):
        return web.json_response({"error": "unauthorized"}, status=401)
    counts = live_counts()
    for c in CHANNEL_CACHE:
        if c["id"] in counts:
            c["humans"], c["total"] = counts[c["id"]]
        else:
            c["humans"] = None
            c["total"] = None
    accounts = []
    for a in ACCOUNTS:
        vc = a.voice
        status = "error" if a.error else ("voice" if vc else ("ready" if a.ready else "idle"))
        accounts.append({
            "label": a.label,
            "status": status,
            "channel": a.channel_name if vc else None,
            "error": a.error,
        })
    return web.json_response({
        "accounts": accounts,
        "channels": CHANNEL_CACHE,
        "guild_id": GUILD_ID,
        "channels_error": CHANNEL_ERROR,
        "ram_mb": round(current_rss_mb(), 1),
        "mem_limit_mb": MEM_LIMIT_MB,
        "max_online": MAX_ONLINE,
        "guard_message": GUARD["message"],
    })


@routes.post("/api/refresh")
async def api_refresh(request):
    global CHANNEL_ERROR
    if not authorized(request):
        return web.json_response({"error": "unauthorized"}, status=401)
    CHANNEL_CACHE.clear()
    data, err = await fetch_channels()
    CHANNEL_CACHE.extend(data)
    CHANNEL_ERROR = err
    msg = err if err else "%d salons vocaux charges" % len(data)
    return web.json_response({"ok": err is None, "message": msg})


@routes.post("/api/join")
async def api_join(request):
    if not authorized(request):
        return web.json_response({"error": "unauthorized"}, status=401)
    try:
        body = await request.json()
    except Exception:
        body = {}
    try:
        channel_id = int(body.get("channel_id") or 0)
    except (TypeError, ValueError):
        channel_id = 0
    if channel_id <= 0:
        return web.json_response({"ok": False, "message": "salon manquant"})
    label = body.get("label")
    if label:
        target = next((a for a in ACCOUNTS if a.label == label), None)
        if target is None:
            return web.json_response({"ok": False, "message": "compte inconnu"})
    else:
        # Priorite : un compte deja en ligne mais libre (zero RAM en plus).
        target = next((a for a in ACCOUNTS if a.ready and a.voice is None and not a.error), None)
        if target is None:
            target = (next((a for a in ACCOUNTS if a.client is None and not a.error), None)
                      or next((a for a in ACCOUNTS if a.client is None), None))
    if target is None:
        return web.json_response({"ok": False, "message": "aucun compte disponible"})
    if target.voice is not None:
        return web.json_response({
            "ok": False,
            "message": "%s est deja en cours d'utilisation (en vocal)" % target.label,
        })
    # Limite RAM : au plus MAX_ONLINE comptes en ligne simultanement.
    if target.client is None:
        online = [a for a in ACCOUNTS if a.ready and a is not target]
        if len(online) >= MAX_ONLINE:
            idle = next((a for a in online if a.voice is None and not a.lock.locked()), None)
            if idle is None:
                return web.json_response({
                    "ok": False,
                    "message": "limite RAM : %d compte(s) en ligne max - deconnecte un compte d'abord"
                               % MAX_ONLINE,
                })
            await idle.safe_shutdown()
    ok, message = await target.join(channel_id)
    return web.json_response({"ok": ok, "message": "%s - %s" % (target.label, message)})


@routes.post("/api/leave")
async def api_leave(request):
    if not authorized(request):
        return web.json_response({"error": "unauthorized"}, status=401)
    try:
        body = await request.json()
    except Exception:
        body = {}
    target = next((a for a in ACCOUNTS if a.label == body.get("label")), None)
    if target is None:
        return web.json_response({"ok": False, "message": "compte inconnu"})
    ok, message = await target.leave()
    return web.json_response({"ok": ok, "message": "%s - %s" % (target.label, message)})


async def initial_refresh():
    global CHANNEL_ERROR
    data, err = await fetch_channels()
    CHANNEL_CACHE.extend(data)
    CHANNEL_ERROR = err
    if err:
        print("Salons : %s" % err)
    else:
        print("Salons vocaux charges : %d" % len(data))


async def main():
    load_accounts()
    apply_hard_rlimit()
    print("[RAM] limite %d Mo - max %d compte(s) en ligne - garde-fou a %d/%d/%d Mo"
          % (MEM_LIMIT_MB, MAX_ONLINE, SOFT1, SOFT2, EMERG))
    app = web.Application()
    app.add_routes(routes)
    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, HOST, PORT).start()
    print("Panneau : http://%s:%d" % (HOST, PORT))
    if CONFIG.get("scanner_online") and ACCOUNTS:
        # Le scanner occupe un slot max_online (~30 Mo en plus).
        spawn(asyncio.create_task(ACCOUNTS[0].ensure_started()))
    spawn(asyncio.create_task(initial_refresh()))
    spawn(asyncio.create_task(memory_watchdog()))
    await asyncio.Event().wait()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
