# Voice Panel

Panneau web minimal pour connecter des **bots Discord** dans les salons vocaux d'un serveur.

- Les tokens restent dans `tokens.json` et ne sont **jamais** envoyés au navigateur (l'API ne renvoie que des labels : « Bot 1 », « Bot 2 »…).
- Chaque compte n'est démarré que quand il sert, et est éteint dès qu'il quitte le vocal → RAM minimale, un seul processus.
- Le bouton « Rejoindre » prend automatiquement un compte **libre** (jamais un compte déjà en vocal, donc jamais un compte « en cours d'utilisation »).
- Connexion **refusée** dans les salons où personne n'est non-mute (vérifié côté serveur, au moment de la connexion).
- Un token de compte utilisateur est refusé explicitement par le programme : automatiser un compte perso (« selfbot ») enfreint les CGU de Discord et le token finit banni. Utilise des tokens de **bots**.
- Plafond RAM configurable (`mem_limit_mb`, défaut **245 Mo**) : maintenu par `max_online` + un garde-fou qui surveille la RAM réelle et éteint des comptes si besoin (voir section RAM).

## Installation

```bash
pip install -r requirements.txt
python run.py
```

Puis ouvre http://127.0.0.1:8080

## Créer / inviter un bot (2 minutes par compte)

1. https://discord.com/developers/applications → **New Application** → onglet **Bot** → **Reset Token** → copie le token dans `tokens.json`.
2. Onglet **OAuth2 → URL Generator** : coche `bot`, permissions **View Channels** + **Connect**, ouvre l'URL générée et invite le bot sur le serveur `1038108273703919746`.

Raccourci d'invitation (remplace `TON_CLIENT_ID`) :

```
https://discord.com/oauth2/authorize?client_id=TON_CLIENT_ID&scope=bot&permissions=1049600
```

## Fichiers

| Fichier | Rôle |
|---|---|
| `run.py` | bot + API web + site, dans un seul processus |
| `web/index.html` | le site (HTML/JS pur, sans framework) |
| `tokens.json` | tes tokens de bots (jamais exposés au web) |
| `config.json` | serveur, port, options |

## config.json

- `guild_id` : ID du serveur (déjà rempli : 1038108273703919746).
- `host` / `port` : `127.0.0.1` = panneau accessible seulement depuis ta machine. Pour un accès réseau : `0.0.0.0` **et** un `panel_password` (le site demandera le mot de passe).
- `self_deaf` : le bot arrive « sourd » dans le vocal (recommandé).
- `scanner_online` : `true` = garde le premier compte connecté au gateway en permanence pour afficher en direct qui est non-mute dans chaque salon (~30 Mo de RAM en plus, occupe un slot `max_online`). `false` = comptes 100 % à la demande.
- `mem_limit_mb` : plafond RAM du processus, défaut `245` (marge sous une limite d'hébergement de 256 Mo).
- `max_online` : nombre max de comptes en ligne en même temps, défaut `2`. Levier principal : la RAM est bornée par construction.
- `idle_shutdown_sec` : un compte en ligne sans vocal s'éteint après ce délai, défaut `120` s.
- `hard_rlimit` : `true` = le plafond est en plus appliqué par le noyau (RLIMIT_AS, Linux uniquement ; compte la mémoire virtuelle, peut couper un peu tôt — défaut `false`).

## RAM — plafond 245 Mo

Le script est fait pour ne **jamais** dépasser `mem_limit_mb` (245 Mo par défaut, marge sous une limite d'hébergement de 256 Mo) :

1. **Par construction** : `max_online` borne le nombre de comptes en ligne (≈ 25–40 Mo chacun). Le panneau refuse de démarrer un nouveau compte au-delà, et éteint d'abord un compte libre s'il y en a un.
2. **Garde-fou actif** : la RAM réelle (RSS) est mesurée toutes les 5 s. À 65 % (≈ 159 Mo) les comptes libres sont éteints, à 80 % (≈ 196 Mo) les comptes en vocal décrochent, à 92 % (≈ 225 Mo) tout est éteint. La barre de RAM s'affiche en direct sur le site.
3. **Hygiène** : discord.py importé paresseusement, `gc` forcé après chaque extinction, cache réduit au strict nécessaire (membres : uniquement ceux en vocal).
4. **Dernier recours** : `hard_rlimit: true` fait appliquer le plafond par le noyau (Linux uniquement).

Ordres de grandeur : panneau seul ~20–35 Mo · 1 compte en vocal ~60–90 Mo au total · 2 comptes ~100–130 Mo. Les 245 Mo ne sont atteignables qu'avec beaucoup de comptes en ligne — et le garde-fou éteint alors des comptes avant d'approcher la limite.

Après un refus (« personne de non-mute »), le compte reste en ligne `idle_shutdown_sec` (2 min par défaut) pour éviter les reconnexions en rafale, puis s'éteint tout seul.

## Notes

- La première connexion d'un compte prend 2–4 s (connexion au gateway Discord).
- Si tu modifies `tokens.json`, relance `run.py`.
